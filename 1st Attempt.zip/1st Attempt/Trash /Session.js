// const { Model, DataTypes } = require('sequelize');
// const sequelize = require('../config/connection');

// class Session extends Model {}

// Session.init(
//   {
//     sid: {
//       type: DataTypes.STRING,
//       primaryKey: true,
//     },
//     expires: {
//       type: DataTypes.DATE,
//     },
//     data: {
//       type: DataTypes.TEXT,
//     },
//     date_created: {
//       type: DataTypes.DATE,
//       allowNull: false,
//     },
//     updated_at: {
//       type: DataTypes.DATE,
//       allowNull: false,
//     },
//   },
//   {
//     sequelize,
//     timestamps: false,
//     freezeTableName: true,
//     underscored: true,
//     modelName: 'session',
//   }
// );

// module.exports = Session;
